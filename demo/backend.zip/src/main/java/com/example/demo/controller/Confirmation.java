package com.example.demo.controller;

public class Confirmation {
    private String message;

    public Confirmation() {
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}