import { React, useState, useEffect } from 'react';
import { Menu, Dropdown, Avatar, Input, message } from 'antd';
import { Link } from 'react-router-dom';
import { logout } from '../service/logout';
import { getUserInfo } from '../service/user';
import { 
    HomeOutlined, 
    BookOutlined, 
    ShoppingCartOutlined, 
    OrderedListOutlined,
    DownOutlined,
    LineChartOutlined,
    UserOutlined,
    SearchOutlined
} from '@ant-design/icons';


const NavBar = () => {   

  const [userInfo, setUserInfo] = useState({ nickname: '', avatarSrc: '' });

  useEffect(() => {
    const fetchUserInfo = async () => {
      const data = await getUserInfo();
      if (data) {
        setUserInfo(data);
      }
    };
    fetchUserInfo();
  }, []);

  const handleLogout = async () => {
    try {
        const response = await logout();
        if (response.ok) { 
            sessionStorage.removeItem('username');
            console.log(response);
            alert(response.message);
            window.location.href = '/login'; 
            
        } else {
          message.error('登出失败');
        }
    } catch (error) {
        console.error('Logout Error:', error);
        message.error('登出失败');
    }
  };

  const menu = (
    <Menu>
      <Menu.Item key="profile">
        <Link to="/user">个人中心</Link>
      </Menu.Item>
      <Menu.Item key="passwd">修改密码</Menu.Item>
      <Menu.Item key="logout" onClick={handleLogout}>退出登录</Menu.Item>
    </Menu>
  );

  return (
    <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['1']}>
      <Menu.Item key="home" icon={<HomeOutlined />} style={{backgroundColor: 'transparent'}}>
        <Link to="/home">首页</Link>
      </Menu.Item>
      <Menu.Item key="book" icon={<BookOutlined />} style={{backgroundColor: 'transparent'}}>
        { (sessionStorage.getItem('username') !== 'admin') && 
                <Link to="/book">书籍</Link> }
        { (sessionStorage.getItem('username') === 'admin') && 
                <Link to="/bookManage">书籍管理</Link> }
      </Menu.Item>
      <Menu.Item key="cart" icon={<ShoppingCartOutlined />} style={{backgroundColor: 'transparent'}}>
        <Link to="/cart">购物车</Link>
      </Menu.Item>
      <Menu.Item key="order" icon={<OrderedListOutlined />} style={{backgroundColor: 'transparent'}}>
        <Link to="/order">订单</Link>
      </Menu.Item> 
      <Menu.Item key="statistics" icon={<LineChartOutlined />} style={{backgroundColor: 'transparent'}}>
        { (sessionStorage.getItem('username') !== 'admin') && 
                <Link to="/userstatistics">购书统计</Link> }
        { (sessionStorage.getItem('username') === 'admin') && 
                <Link to="/statistics">统计</Link> }
      </Menu.Item> 
      {(sessionStorage.getItem('username') === 'admin') && 
      (<Menu.Item key="manage" icon={<UserOutlined />} style={{backgroundColor: 'transparent'}}>
        <Link to="/manage">用户管理</Link>
      </Menu.Item> )}
{/*       <Menu.Item key="search" style={{ flexGrow: 1, backgroundColor:'transparent'}}>
        <Input
          placeholder="搜索"
          prefix={<SearchOutlined />}
          style={{ width: 700 }}
        />
      </Menu.Item> */}
    <Menu.Item style={{ flexGrow: 1, pointerEvents: 'none' }}></Menu.Item>
      <Menu.Item key="profile" style={{ marginRight: 20, backgroundColor:'transparent' }}>
        <Dropdown overlay={menu} trigger={['click']}>
          <span className="ant-dropdown-link" onClick={(e) => e.preventDefault()}>
            {userInfo.nickname}
            <Avatar src={userInfo.avatarSrc} style={{ marginLeft: 6, marginRight: 4 }} />
            <DownOutlined />
          </span>
        </Dropdown>
      </Menu.Item>
    </Menu>
  );
};

export default NavBar;



