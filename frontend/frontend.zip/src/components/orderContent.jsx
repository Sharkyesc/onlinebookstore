import React, { useState } from 'react';
import { Table, Button, Typography, Divider, Modal } from 'antd';
import { Link } from 'react-router-dom';

const { Title } = Typography;

const OrderContent = ({ orderInfo }) => {

    const [modalVisible, setModalVisible] = useState(false);
    const [selectedOrder, setSelectedOrder] = useState(null);

    const handleViewDetails = (order) => {
        setSelectedOrder(order);
        setModalVisible(true);
      };
    
      const columns = [
        {
          title: '订单编号',
          dataIndex: 'orderId',
          key: 'orderId',
        },
        {
          title: '订单时间',
          dataIndex: 'orderTime',
          key: 'orderTime',
        },
        {
          title: '收货地址',
          dataIndex: 'destination',
          key: 'destination',
        },
        {
          title: '总价',
          dataIndex: 'totalPrice',
          key: 'totalPrice',
        },
        {
          title: '详情',
          key: 'action',
          render: (text, record) => (
            <Button type="link" onClick={() => handleViewDetails(record)}>查看详情</Button>
          ),
        },
      ];
  
  return (
    <div className="site-layout-content">
      <Title level={2}>订单详情</Title>
      <Divider />
      <Table columns={columns} dataSource={orderInfo} />
      <div style={{ marginTop: 20 }}>
        <Link to="/home">
          <Button type="primary">继续购物</Button>
        </Link>
      </div>
      <Modal
        title="订单详情"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
      >
        {selectedOrder && (
          <>
            <p>订单编号：{selectedOrder.orderId}</p>
            <p>订单时间：{selectedOrder.orderTime}</p>
            <p>收货地址：{selectedOrder.destination}</p>
            <p>总价：{selectedOrder.totalPrice}</p>
            {selectedOrder.orderItems.map((item, index) => (
                <div key={index}>
                    <h4>订单项编号: {item.itemId}</h4>
                    <p>书籍编号: {item.bookId}</p>
                    <p>数量: {item.quantity}</p>
                    <p>单项总价: {item.price}</p>
                </div>
            ))}

          </>
        )}
      </Modal>
    </div>
  );

};

export default OrderContent;


