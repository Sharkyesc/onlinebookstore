package com.example.demo.dao;

import com.example.demo.entity.OrderItem;

public interface OrderItemDao {
    void saveOrderItem(OrderItem orderItem);

}