package com.example.demo.service;

import com.example.demo.dao.UserDao;
import com.example.demo.entity.User;
import com.example.demo.entity.UserAuth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

import org.mindrot.jbcrypt.BCrypt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    public String encodePassword(String rawPassword) {
        return BCrypt.hashpw(rawPassword, BCrypt.gensalt());
    }

    public boolean matchesPassword(String rawPassword, String hashedPassword) {
        return BCrypt.checkpw(rawPassword, hashedPassword);
    }

    @Override
    public User findById(Integer id) {
        return userDao.findById(id);
    }

    @Override
    public User findByUsername(String username) {
        return userDao.findByUsername(username);
    }

    @Transactional
    @Override
    public void registerUser(String name, String username, String email, String password) {

        User user = new User();
        user.setNickname(name);
        user.setEmail(email);

        UserAuth userAuth = new UserAuth();
        userAuth.setUser(user);
        userAuth.setUsername(username);
        userAuth.setPassword(encodePassword(password));
        user.setUserAuth(userAuth);
        userDao.saveUser(user);
    }

    @Autowired
    private HttpServletRequest request;

    @Override
    public User getCurUser() {
        HttpSession session = request.getSession(false);

        String username = (String) session.getAttribute("user");

        return findByUsername(username);
    }

    @Override
    public void updateUser(User user) {
        userDao.saveUser(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userDao.findAll();
    }

    @Override
    public void disableUser(int userId) {
        User user = userDao.findById(userId);
        user.setEnabled(false);
        userDao.saveUser(user);
    }

    @Override
    public void enableUser(int userId) {
        User user = userDao.findById(userId);
        user.setEnabled(true);
        userDao.saveUser(user);
    }
}